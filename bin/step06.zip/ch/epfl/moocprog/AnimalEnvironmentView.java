package ch.epfl.moocprog;

public interface AnimalEnvironmentView {
    
}
