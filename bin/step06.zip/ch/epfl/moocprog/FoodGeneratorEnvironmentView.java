package ch.epfl.moocprog;


public interface FoodGeneratorEnvironmentView {
    void addFood(Food food);
}
