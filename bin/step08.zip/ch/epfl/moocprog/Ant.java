package ch.epfl.moocprog;

import ch.epfl.moocprog.utils.Time;

public abstract class Ant extends Animal{
    private Uid AnthillId;

    public Ant(ToricPosition position,int hitpoints,Time lifespan,Uid AnthillId) {
        super(position,hitpoints,lifespan);
        this.AnthillId = AnthillId;
    }
    public final Uid getAnthillId(){
        return this.AnthillId;
    }
    public String toString(){
        return super.toString();
    }
}
