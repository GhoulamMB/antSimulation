package ch.epfl.moocprog;

public interface AntEnvironmentView extends AnimalEnvironmentView{
    
}
