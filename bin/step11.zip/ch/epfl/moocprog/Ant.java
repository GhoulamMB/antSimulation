package ch.epfl.moocprog;

import ch.epfl.moocprog.utils.Time;
import ch.epfl.moocprog.utils.Vec2d;

import static ch.epfl.moocprog.app.Context.getConfig;
import static ch.epfl.moocprog.config.Config.ANT_PHEROMONE_DENSITY;
import static ch.epfl.moocprog.config.Config.ANT_PHEROMONE_ENERGY;
public abstract class Ant extends Animal{
    private Uid AnthillId;
    private ToricPosition lastPos;
    private static final double DENSITE = getConfig().getDouble(ANT_PHEROMONE_DENSITY);
    public Ant(ToricPosition position,int hitpoints,Time lifespan,Uid AnthillId) {
        super(position,hitpoints,lifespan);
        this.AnthillId = AnthillId;
        this.lastPos = new ToricPosition(position.toVec2d().getX(), position.toVec2d().getY());
    }
    public final Uid getAnthillId(){
        return this.AnthillId;
    }
    public final void spreadPheromones(AntEnvironmentView env) {
		double densite = getConfig().getDouble(ANT_PHEROMONE_DENSITY);
		ToricPosition currentPos = this.getPosition();
		double d = lastPos.toricDistance(currentPos);
		int numPheros = (int) (d * densite);
		double step = d / numPheros;
		Vec2d direction = this.lastPos.toricVector(currentPos).normalized();
		for (int i = 0; i < numPheros; ++i) {
			this.lastPos = this.lastPos.add(direction.scalarProduct(step));
			env.addPheromone(new Pheromone(this.lastPos, getConfig().getDouble(ANT_PHEROMONE_ENERGY))); 

		}
	}
    @Override
    protected final RotationProbability computeRotationProbsDispatch(AnimalEnvironmentView env) {
        return env.selectComputeRotationProbsDispatch(this);
    }
    @Override
    protected final void afterMoveDispatch(AnimalEnvironmentView env, Time dt) {
        env.selectAfterMoveDispatch(this, dt);
    }
    protected final RotationProbability computeRotationProbs(AntEnvironmentView env){
        return computeDefaultRotationProbs();
    }
    protected final void afterMoveAnt(AntEnvironmentView env, Time dt){
        this.spreadPheromones(env);
    }
    public String toString(){
        return super.toString();
    }
}
