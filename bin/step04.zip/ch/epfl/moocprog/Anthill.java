package ch.epfl.moocprog;

public final class Anthill extends Positionable{
    public Anthill(ToricPosition toric){
        super(toric);
    }
    public double getQuantity(){
        return 0.0;
    }
    public double getFoodQuantity(){
        return 0.0;
    }
}
