package ch.epfl.moocprog;

public abstract class Ant extends Animal{

    public Ant(ToricPosition position) {
        super(position);
        //TODO Auto-generated constructor stub
    }
    
}
