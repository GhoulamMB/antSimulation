package ch.epfl.moocprog;

abstract public class Animal extends Positionable{
    private double angle;
    public Animal(ToricPosition position){
        super(position);
        this.angle=0.0;
    }
    public final double getDirection(){
        return this.angle;
    }
    abstract public void accept(AnimalVisitor visitor, RenderingMedia s);
}
