package ch.epfl.moocprog;

import static ch.epfl.moocprog.app.Context.getConfig;
import static ch.epfl.moocprog.config.Config.ANT_WORKER_HP;
import static ch.epfl.moocprog.config.Config.ANT_WORKER_LIFESPAN;
import static ch.epfl.moocprog.config.Config.ANT_WORKER_SPEED;

public final class AntWorker extends Ant{
    private double transprtedFoodQte=0.0;
    public AntWorker(ToricPosition position, Uid AnthillId) {
        super(position,getConfig().getInt(ANT_WORKER_HP),getConfig().getTime(ANT_WORKER_LIFESPAN),AnthillId);
    }

    @Override
    public void accept(AnimalVisitor visitor, RenderingMedia s) {
        visitor.visit(this, s);
        
    }

    @Override
    public double getSpeed() {
        return getConfig().getDouble(ANT_WORKER_SPEED);
    }
    public double getFoodQuantity(){
        return this.transprtedFoodQte;
    }
    public String toString(){
        return super.toString()+"\nQuantity : "+this.transprtedFoodQte;
    }
}
