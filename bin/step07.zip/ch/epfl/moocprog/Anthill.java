package ch.epfl.moocprog;
import static ch.epfl.moocprog.app.Context.getConfig;
import static ch.epfl.moocprog.config.Config.ANTHILL_WORKER_PROB_DEFAULT;
public final class Anthill extends Positionable{
    private double foodStock = 0.0;
    private Uid anthillID;
    private double probabilitytoSeeAntWorker;
    public Anthill(ToricPosition toric,double probabilitytoSeeAntWorker){
        super(toric);
        this.probabilitytoSeeAntWorker = probabilitytoSeeAntWorker;
        this.anthillID = Uid.createUid();
    }
    public Anthill(ToricPosition toric){
        super(toric);
        this.probabilitytoSeeAntWorker = getConfig().getDouble(ANTHILL_WORKER_PROB_DEFAULT);
        this.anthillID = Uid.createUid();
    }
    public void dropFood(double toDrop){
        if(toDrop<0){
            throw new IllegalArgumentException();
        }else{
            this.foodStock += toDrop;
        }
    }
    public double getQuantity(){
        return 0.0;
    }
    public double getFoodQuantity(){
        return this.foodStock;
    }
    public Uid getAnthillId(){
        return this.anthillID;
    }
    public String toString(){
        double X = this.getPosition().toVec2d().getX();
        double Y = this.getPosition().toVec2d().getY();
        return "Position : "+X+", "+Y+"\nQuantity : "+this.foodStock;
    }
}
