package ch.epfl.moocprog;

public interface TermiteEnvironmentView extends AnimalEnvironmentView{
    
}
