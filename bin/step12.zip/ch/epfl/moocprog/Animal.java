package ch.epfl.moocprog;

import ch.epfl.moocprog.utils.Time;
import ch.epfl.moocprog.utils.Utils;
import ch.epfl.moocprog.utils.Vec2d;
import ch.epfl.moocprog.random.UniformDistribution;
import static ch.epfl.moocprog.app.Context.getConfig;
import static ch.epfl.moocprog.config.Config.ANIMAL_LIFESPAN_DECREASE_FACTOR;
import static ch.epfl.moocprog.config.Config.ANIMAL_NEXT_ROTATION_DELAY;

abstract public class Animal extends Positionable{
    private double angle;
    private int hitpoints;
    private Time lifespan;
    private Time rotationDelay = Time.ZERO;
    abstract public void accept(AnimalVisitor visitor, RenderingMedia s);
    abstract public double getSpeed();
    protected abstract void specificBehaviorDispatch(AnimalEnvironmentView env, Time dt);
    protected abstract RotationProbability computeRotationProbsDispatch(AnimalEnvironmentView env);
    protected abstract void afterMoveDispatch(AnimalEnvironmentView env, Time dt);
    public Animal(ToricPosition position){
        super(position);
    }
    public Animal(ToricPosition Position,int HitPoints,Time lifespan){
        super(Position);
        this.angle=UniformDistribution.getValue(0.0, 2*Math.PI);
        this.hitpoints = HitPoints;
        this.lifespan = lifespan;
    }
    public final double getDirection(){
        return this.angle;
    }
    public final void setDirection(double angle){
        this.angle = angle;
    }
    public final int getHitpoints(){
        return this.hitpoints;
    }
    public final Time getLifespan(){
        return this.lifespan;
    }
    public final boolean isDead(){
        if(this.hitpoints<=0 || this.lifespan.toMilliseconds()<=0){
            return true;
        }
        return false;
    }
    public final void update(AnimalEnvironmentView env, Time dt){
        this.lifespan = getLifespan().minus(dt.times(getConfig().getDouble(ANIMAL_LIFESPAN_DECREASE_FACTOR)));
        if(!this.isDead()){
            this.specificBehaviorDispatch(env, dt);
            //this.move(dt);
        }
    }
    protected final void move(AnimalEnvironmentView env,Time dt){
        this.rotationDelay = this.rotationDelay.plus(dt);
        Time Delay = getConfig().getTime(ANIMAL_NEXT_ROTATION_DELAY);
        if(!this.isDead()){
            while(this.rotationDelay.compareTo(Delay)>=0){
                Rotate(env);
                this.rotationDelay = this.rotationDelay.minus(Delay);
            }
        }
        setPosition(this.getPosition().add(Vec2d.fromAngle(this.angle).scalarProduct(dt.toSeconds()*(getSpeed()))));
        afterMoveDispatch(env, dt);
    }
    private void Rotate(AnimalEnvironmentView env){
        this.angle += Utils.pickValue(this.computeRotationProbsDispatch(env).getAngles(),this.computeRotationProbsDispatch(env).getProbabilities());
    }
    public void makeTurn(){
        double tempangle = getDirection();
        if(tempangle + Math.PI > 2*Math.PI){
            this.setDirection(tempangle-Math.PI);
        }else{
            this.setDirection(tempangle+Math.PI);
        }
    }
    protected final RotationProbability computeDefaultRotationProbs(){
        double[] anglesinDegree = {-180.0,-100.0,-55.0,-25.0,-10.0,0.0,10.0,25.0,55.0,100.0,180.0};
        double[] Probabilities = {0.0000,0.0000,0.0005,0.0010,0.0050,0.9870,0.0050,0.0010,0.0005,0.0000,0.0000};
        double[] AnglesinRadians = new double[anglesinDegree.length];
        for(int i=0;i<anglesinDegree.length;++i){
            AnglesinRadians[i] = Math.toRadians(anglesinDegree[i]);
        }
        //AnglesinRadians = AnglesinRadians.clone();
        return new RotationProbability(AnglesinRadians, Probabilities);
    }
    public String toString(){
        return "Position : "+this.getPosition().toVec2d().toString()+"\nSpeed : "+this.getSpeed()+"\nHitPoints : "+this.hitpoints+"\nLifeSpan : "+this.lifespan.toMilliseconds();
    }
}
