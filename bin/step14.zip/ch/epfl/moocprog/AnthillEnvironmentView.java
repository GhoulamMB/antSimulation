package ch.epfl.moocprog;

public interface AnthillEnvironmentView {
    void addAnt(Ant ant);
}
