package ch.epfl.moocprog;

import static ch.epfl.moocprog.app.Context.getConfig;
import static ch.epfl.moocprog.config.Config.TERMITE_SPEED;

import ch.epfl.moocprog.utils.Time;

import static ch.epfl.moocprog.config.Config.TERMITE_HP;
import static ch.epfl.moocprog.config.Config.TERMITE_LIFESPAN;;

public final class Termite extends Animal{

    public Termite(ToricPosition position) {
        super(position, getConfig().getInt(TERMITE_HP), getConfig().getTime(TERMITE_LIFESPAN));
    }
    
    protected void seekForEnemies(AnimalEnvironmentView env , Time dt){
        this.move(dt);
    }
    @Override
    public void accept(AnimalVisitor visitor, RenderingMedia s) {
        visitor.visit(this, s);
    }

    @Override
    public double getSpeed() {
        return getConfig().getDouble(TERMITE_SPEED);
    }

    @Override
	public void specificBehaviorDispatch(AnimalEnvironmentView env, Time dt) {
		//env.selectSpecificBehaviorDispatch(this, dt);
	}
    
}
