package ch.epfl.moocprog;

import static ch.epfl.moocprog.app.Context.getConfig;
import static ch.epfl.moocprog.config.Config.ANT_WORKER_HP;
import static ch.epfl.moocprog.config.Config.ANT_WORKER_LIFESPAN;
import static ch.epfl.moocprog.config.Config.ANT_WORKER_SPEED;
import static ch.epfl.moocprog.config.Config.ANT_MAX_FOOD;

import ch.epfl.moocprog.utils.Time;

public final class AntWorker extends Ant{
    private double foodQuantity=0.0;
    public AntWorker(ToricPosition position, Uid AnthillId) {
        super(position,getConfig().getInt(ANT_WORKER_HP),getConfig().getTime(ANT_WORKER_LIFESPAN),AnthillId);
    }
    public AntWorker(ToricPosition position, int hitpoints , Time lifespan , Uid AnthillId){
        super(position, hitpoints, lifespan, AnthillId);
    }
    @Override
    public void accept(AnimalVisitor visitor, RenderingMedia s) {
        visitor.visit(this, s);
    }
    @Override
    public double getSpeed() {
        return getConfig().getDouble(ANT_WORKER_SPEED);
    }
    public double getFoodQuantity(){
        return this.foodQuantity;
    }
    protected void seekForFood(AntWorkerEnvironmentView env, Time dt){
        this.move(dt);
        if(env.getClosestFoodForAnt(this)!= null && this.foodQuantity == 0.0){
            double quantity = env.getClosestFoodForAnt(this).takeQuantity(getConfig().getDouble(ANT_MAX_FOOD));
            this.foodQuantity = quantity;
            this.makeTurn();
        }
        if(env.dropFood(this) && this.foodQuantity != 0.0){
            this.foodQuantity = 0.0;
            this.makeTurn();
        }
    }
    @Override
    protected void specificBehaviorDispatch(AnimalEnvironmentView env, Time dt) {
        env.selectSpecificBehaviorDispatch(this, dt);
    }
    public String toString(){
        return super.toString()+"\nQuantity : "+this.foodQuantity;
    }

    
}
