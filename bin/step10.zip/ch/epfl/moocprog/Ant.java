package ch.epfl.moocprog;

import ch.epfl.moocprog.utils.Time;
import ch.epfl.moocprog.utils.Vec2d;

import static ch.epfl.moocprog.app.Context.getConfig;
import static ch.epfl.moocprog.config.Config.ANT_PHEROMONE_ENERGY;
import static ch.epfl.moocprog.config.Config.ANT_PHEROMONE_DENSITY;
public abstract class Ant extends Animal{
    private Uid AnthillId;
    private ToricPosition lastPos;
    public Ant(ToricPosition position,int hitpoints,Time lifespan,Uid AnthillId) {
        super(position,hitpoints,lifespan);
        this.AnthillId = AnthillId;
        this.lastPos = position;
    }
    public final Uid getAnthillId(){
        return this.AnthillId;
    }
    private final void spreadPheromones(AntEnvironmentView env){
        ToricPosition currentPos = this.getPosition();
        double d = lastPos.toricDistance(currentPos);
        Vec2d v = lastPos.toricVector(currentPos);
        double densite = getConfig().getDouble(ANT_PHEROMONE_DENSITY);
        for(int i=0;i<d*densite;++i){
            ToricPosition pos_i = lastPos.add(v.scalarProduct(i/(d*densite)));
            Pheromone pheromone = new Pheromone(pos_i, getConfig().getDouble(ANT_PHEROMONE_ENERGY));
            env.addPheromone(pheromone);
            this.lastPos = currentPos;
        }
    }
    public String toString(){
        return super.toString();
    }
}
