package ch.epfl.moocprog;

import ch.epfl.moocprog.utils.Time;
import ch.epfl.moocprog.utils.Vec2d;
import ch.epfl.moocprog.random.UniformDistribution;
import static ch.epfl.moocprog.app.Context.getConfig;
import static ch.epfl.moocprog.config.Config.ANIMAL_LIFESPAN_DECREASE_FACTOR;

abstract public class Animal extends Positionable{
    private double angle;
    private int hitpoints;
    private Time lifespan;
    abstract public void accept(AnimalVisitor visitor, RenderingMedia s);
    abstract public double getSpeed();
    public Animal(ToricPosition position){
        super(position);
    }
    public Animal(ToricPosition Position,int HitPoints,Time lifespan){
        super(Position);
        this.angle=UniformDistribution.getValue(0.0, 2*Math.PI);
        this.hitpoints = HitPoints;
        this.lifespan = lifespan;
    }
    public final double getDirection(){
        return this.angle;
    }
    public final void setDirection(double angle){
        this.angle = angle;
    }
    public final int getHitpoints(){
        return this.hitpoints;
    }
    public final Time getLifespan(){
        return this.lifespan;
    }
    public final boolean isDead(){
        if(this.hitpoints<=0 || this.lifespan.toMilliseconds()<=0){
            return true;
        }
        return false;
    }
    public void update(AnimalEnvironmentView env, Time dt){
        this.lifespan = getLifespan().minus(dt.times(getConfig().getDouble(ANIMAL_LIFESPAN_DECREASE_FACTOR)));
        if(!this.isDead()){
            this.move(dt);
        }
    }
    protected final void move(Time dt){
		setPosition(this.getPosition().add(Vec2d.fromAngle(this.angle).scalarProduct(dt.toSeconds()*(getSpeed()))));
    }
    public String toString(){
        return "Position : "+this.getPosition().toVec2d().toString()+"\nSpeed : "+this.getSpeed()+"\nHitPoints : "+this.hitpoints+"\nLifeSpan : "+this.lifespan.toMilliseconds();
    }
}
