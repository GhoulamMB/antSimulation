package ch.epfl.moocprog;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import ch.epfl.moocprog.utils.Time;

public final class Environment implements FoodGeneratorEnvironmentView{
    private FoodGenerator fgen;
    private LinkedList<Food> foods;
    public Environment(){
        this.fgen = new FoodGenerator();
        this.foods = new LinkedList<Food>();
    }
    @Override
    public void addFood(Food food) {
        if(food == null){
            throw new IllegalArgumentException();
        }else{
            this.foods.add(food);
        }
    }
    public List<Double> getFoodQuantities(){
        ArrayList<Double> tmp = new ArrayList<Double>();
        for(Food i:this.foods){
            tmp.add(i.getQuantity());
        }
        return tmp;
    }
    public void update(Time dt){
        fgen.update(this, dt);
        foods.removeIf(food -> food.getQuantity() <= 0);
    }
}
